# Macuma — Banque de travail de la CUMA

Application web pour gérer les échanges de travail entre adhérents :
saisie des heures (en unités), chantiers collectifs (ensilage…),
validation par chacun, et soldes mis à jour en direct.

## 1. Prérequis

- Node.js 18 ou plus récent (https://nodejs.org)
- Un projet Supabase avec le schéma `macuma_schema.sql` déjà exécuté

## 2. Installation

Dans un terminal, à la racine du projet :

    npm install

## 3. Configuration

1. Copier le fichier `.env.local.example` et le renommer `.env.local`
2. Dans Supabase > Project Settings > API, copier :
   - "Project URL" → NEXT_PUBLIC_SUPABASE_URL
   - "anon public" → NEXT_PUBLIC_SUPABASE_ANON_KEY

## 4. Complément de sécurité (à exécuter une fois dans Supabase)

Dans Supabase > SQL Editor, coller et exécuter :

    revoke all on public.soldes from anon;
    revoke all on public.soldes_par_campagne from anon;
    alter view public.soldes set (security_invoker = on);
    alter view public.soldes_par_campagne set (security_invoker = on);

(Cela garantit que les soldes ne sont visibles que par les membres connectés.)

## 5. Premier responsable

1. Lancer le site (étape 6), créer votre compte via "Créer un compte"
2. Dans Supabase > SQL Editor, vous donner le rôle responsable :

    update public.profils set role = 'responsable'
    where email = 'votre-email@exemple.fr';

3. Ensuite, tout se gère depuis l'onglet Admin du site :
   rôles des membres (adhérent / salarié / responsable), types de
   travail, valeur de l'unité, campagnes.

Astuce : pour simplifier les inscriptions, vous pouvez désactiver la
confirmation par e-mail dans Supabase > Authentication > Providers >
Email > "Confirm email" (décocher).

## 6. Lancer en local

    npm run dev

Puis ouvrir http://localhost:3000

## 7. Déployer sur Vercel

1. Pousser le projet sur GitHub (ou importer le dossier directement)
2. Sur vercel.com : "Add New Project" → importer le dépôt
3. Dans "Environment Variables", ajouter les deux variables du `.env.local`
4. Déployer — le site sera en ligne en une minute

## Comment ça marche

- **Adhérent** : saisit ses heures chez un autre adhérent, valide les
  échanges qui le concernent, suit son solde en direct.
- **Salarié** (chauffeur d'ensileuse) : crée un chantier, ajoute une
  ligne par participant ; chacun valide ensuite la sienne. Pas de solde.
- **Responsable** : tout cela, plus l'administration (membres, taux,
  valeur de l'unité, campagnes, bilans).

Règles importantes :
- On ne valide jamais sa propre saisie : c'est l'autre partie qui valide.
- Chaque échange photographie le taux d'unités du type de travail et la
  valeur de l'unité au moment de la saisie : changer un taux ou la
  valeur de l'unité ne modifie jamais le passé.
- Le solde = unités données − unités reçues, recalculé à chaque
  validation (et affiché aussi en euros).
