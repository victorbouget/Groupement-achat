"use client";

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { fmtUnites, fmtEuros } from "@/lib/format";

export default function PageSoldes() {
  const [soldes, setSoldes] = useState([]);
  const [chargement, setChargement] = useState(true);

  const charger = useCallback(async () => {
    const { data } = await supabase
      .from("soldes")
      .select("*")
      .order("nom");
    setSoldes(data || []);
    setChargement(false);
  }, []);

  useEffect(() => {
    charger();
    const canal = supabase
      .channel("maj-soldes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "echanges" },
        charger
      )
      .subscribe();
    return () => supabase.removeChannel(canal);
  }, [charger]);

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Soldes des adhérents</h1>
      <p className="text-sm text-ink/60">
        Mis à jour en direct à chaque validation. Un solde positif signifie que
        l'adhérent a donné plus de travail qu'il n'en a reçu.
      </p>

      {chargement && <p className="text-ink/50">Chargement…</p>}

      <div className="carte p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-prairie-light text-prairie-dark text-left">
              <th className="px-3 py-2 font-semibold">Adhérent</th>
              <th className="px-3 py-2 font-semibold text-right">Unités</th>
              <th className="px-3 py-2 font-semibold text-right">Euros</th>
            </tr>
          </thead>
          <tbody>
            {soldes.map((s) => (
              <tr key={s.id} className="border-t border-ink/5">
                <td className="px-3 py-2.5 font-semibold">
                  {s.prenom} {s.nom}
                </td>
                <td
                  className={`px-3 py-2.5 text-right font-display font-bold ${
                    s.solde_unites >= 0 ? "text-prairie" : "text-terre"
                  }`}
                >
                  {s.solde_unites > 0 ? "+" : ""}
                  {fmtUnites(s.solde_unites)}
                </td>
                <td
                  className={`px-3 py-2.5 text-right ${
                    s.solde_euros >= 0 ? "text-prairie" : "text-terre"
                  }`}
                >
                  {fmtEuros(s.solde_euros)}
                </td>
              </tr>
            ))}
            {!chargement && soldes.length === 0 && (
              <tr>
                <td colSpan={3} className="px-3 py-4 text-ink/50">
                  Aucun adhérent pour le moment.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
