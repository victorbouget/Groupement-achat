"use client";

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { fmtUnites, fmtEuros, fmtDate, nomComplet } from "@/lib/format";
import { Check, X } from "lucide-react";

const SELECTION = `
  *,
  travailleur:profils!echanges_travailleur_id_fkey(nom, prenom, email),
  beneficiaire:profils!echanges_beneficiaire_id_fkey(nom, prenom, email),
  type:types_travail(libelle),
  createur:profils!echanges_cree_par_fkey(nom, prenom, email)
`;

export default function PageValidation() {
  const { user, profil } = useAuth();
  const [enAttente, setEnAttente] = useState([]);
  const [mesSaisies, setMesSaisies] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState("");

  const charger = useCallback(async () => {
    if (!user) return;
    const estResponsable = profil?.role === "responsable";

    let req = supabase
      .from("echanges")
      .select(SELECTION)
      .eq("statut", "en_attente")
      .order("date_echange", { ascending: false });

    if (!estResponsable) {
      req = req
        .or(`travailleur_id.eq.${user.id},beneficiaire_id.eq.${user.id}`)
        .neq("cree_par", user.id);
    }

    const [{ data: a }, { data: m }] = await Promise.all([
      req,
      supabase
        .from("echanges")
        .select(SELECTION)
        .eq("statut", "en_attente")
        .eq("cree_par", user.id)
        .order("date_echange", { ascending: false })
    ]);

    setEnAttente(
      (a || []).filter((e) => estResponsable || e.cree_par !== user.id)
    );
    setMesSaisies(m || []);
    setChargement(false);
  }, [user, profil]);

  useEffect(() => {
    charger();
  }, [charger]);

  async function decider(id, statut) {
    setErreur("");
    const { error } = await supabase
      .from("echanges")
      .update({ statut })
      .eq("id", id);
    if (error) setErreur("Action impossible : " + error.message);
    else charger();
  }

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-bold">À valider</h1>

      {erreur && <p className="text-terre text-sm">{erreur}</p>}

      {chargement && <p className="text-ink/50">Chargement…</p>}

      {!chargement && enAttente.length === 0 && (
        <p className="text-ink/50">
          Rien à valider pour le moment. Tout est à jour 👍
        </p>
      )}

      <div className="space-y-3">
        {enAttente.map((e) => (
          <div key={e.id} className="carte space-y-3">
            <div>
              <p className="font-semibold">
                {nomComplet(e.travailleur)} → chez {nomComplet(e.beneficiaire)}
              </p>
              <p className="text-sm text-ink/60">
                {e.type?.libelle} · {fmtUnites(e.heures)} h ·{" "}
                {fmtDate(e.date_echange)}
              </p>
              <p className="text-sm font-semibold text-prairie-dark mt-1">
                {fmtUnites(e.unites)} unités · {fmtEuros(e.montant_euros)}
              </p>
              {e.commentaire && (
                <p className="text-sm text-ink/60 italic mt-1">
                  « {e.commentaire} »
                </p>
              )}
              <p className="text-xs text-ink/40 mt-1">
                Saisi par {nomComplet(e.createur)}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                className="btn-primaire"
                onClick={() => decider(e.id, "valide")}
              >
                <Check size={18} /> Valider
              </button>
              <button
                className="btn-danger"
                onClick={() => decider(e.id, "refuse")}
              >
                <X size={18} /> Refuser
              </button>
            </div>
          </div>
        ))}
      </div>

      {mesSaisies.length > 0 && (
        <section>
          <h2 className="font-display font-bold text-lg mb-2">
            Mes saisies en attente chez les autres
          </h2>
          <div className="space-y-2">
            {mesSaisies.map((e) => (
              <div key={e.id} className="carte py-3">
                <p className="font-semibold">
                  {nomComplet(e.travailleur)} → chez{" "}
                  {nomComplet(e.beneficiaire)}
                </p>
                <p className="text-sm text-ink/60">
                  {e.type?.libelle} · {fmtUnites(e.heures)} h ·{" "}
                  {fmtDate(e.date_echange)} · {fmtUnites(e.unites)} u
                </p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
