"use client";

import { useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabase";
import {
  LayoutDashboard,
  PlusCircle,
  Tractor,
  ClipboardCheck,
  Users,
  Settings,
  LogOut
} from "lucide-react";

const liens = [
  { href: "/tableau-de-bord", label: "Accueil", icone: LayoutDashboard },
  { href: "/saisie", label: "Saisir", icone: PlusCircle },
  { href: "/chantiers", label: "Chantiers", icone: Tractor },
  { href: "/validation", label: "Valider", icone: ClipboardCheck },
  { href: "/soldes", label: "Soldes", icone: Users }
];

export default function LayoutApp({ children }) {
  const { user, profil, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <main className="min-h-screen flex items-center justify-center text-ink/50">
        Chargement…
      </main>
    );
  }

  const estResponsable = profil?.role === "responsable";
  const tous = estResponsable
    ? [...liens, { href: "/admin", label: "Admin", icone: Settings }]
    : liens;

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <header className="bg-prairie-dark text-white">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/tableau-de-bord" className="font-display text-xl font-extrabold tracking-tight">
            Macuma
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {tous.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`px-3 py-1.5 rounded-lg text-sm font-semibold ${
                  pathname.startsWith(l.href)
                    ? "bg-white/15"
                    : "hover:bg-white/10"
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              router.replace("/login");
            }}
            className="flex items-center gap-1.5 text-sm text-white/80 hover:text-white"
            title="Se déconnecter"
          >
            <LogOut size={16} />
            <span className="hidden sm:inline">Quitter</span>
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-5">{children}</main>

      {/* Barre de navigation mobile */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-ink/10">
        <div className="grid grid-cols-5">
          {(estResponsable ? [...liens.slice(0, 4), { href: "/admin", label: "Admin", icone: Settings }] : liens).map(
            (l) => {
              const Icone = l.icone;
              const actif = pathname.startsWith(l.href);
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`flex flex-col items-center gap-0.5 py-2 text-[11px] font-semibold ${
                    actif ? "text-prairie" : "text-ink/50"
                  }`}
                >
                  <Icone size={22} strokeWidth={actif ? 2.4 : 2} />
                  {l.label}
                </Link>
              );
            }
          )}
        </div>
      </nav>
    </div>
  );
}
