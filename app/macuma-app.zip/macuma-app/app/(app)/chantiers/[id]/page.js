"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { fmtUnites, fmtEuros, fmtDate, nomComplet } from "@/lib/format";
import { Statut } from "@/lib/Statut";
import { Trash2 } from "lucide-react";

export default function DetailChantier() {
  const { id } = useParams();
  const { user, profil } = useAuth();

  const [chantier, setChantier] = useState(null);
  const [lignes, setLignes] = useState([]);
  const [adherents, setAdherents] = useState([]);
  const [types, setTypes] = useState([]);

  const [travailleurId, setTravailleurId] = useState("");
  const [typeId, setTypeId] = useState("");
  const [heures, setHeures] = useState("");
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);

  const peutToutSaisir =
    profil?.role === "salarie" ||
    profil?.role === "responsable" ||
    chantier?.cree_par === user?.id;

  const charger = useCallback(async () => {
    const [{ data: c }, { data: l }, { data: a }, { data: t }] =
      await Promise.all([
        supabase
          .from("chantiers")
          .select(
            `*, beneficiaire:profils!chantiers_beneficiaire_id_fkey(nom, prenom, email)`
          )
          .eq("id", id)
          .single(),
        supabase
          .from("echanges")
          .select(
            `*,
             travailleur:profils!echanges_travailleur_id_fkey(nom, prenom, email),
             type:types_travail(libelle)`
          )
          .eq("chantier_id", id)
          .order("cree_le"),
        supabase
          .from("profils")
          .select("id, nom, prenom, email")
          .eq("role", "adherent")
          .eq("actif", true)
          .order("nom"),
        supabase
          .from("types_travail")
          .select("*")
          .eq("actif", true)
          .order("libelle")
      ]);
    setChantier(c);
    setLignes(l || []);
    setAdherents(a || []);
    setTypes(t || []);
  }, [id]);

  useEffect(() => {
    charger();
    const canal = supabase
      .channel(`chantier-${id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "echanges" },
        charger
      )
      .subscribe();
    return () => supabase.removeChannel(canal);
  }, [charger, id]);

  useEffect(() => {
    if (user && !peutToutSaisir) setTravailleurId(user.id);
  }, [user, peutToutSaisir]);

  const totaux = useMemo(() => {
    const valides = lignes.filter((l) => l.statut === "valide");
    return {
      unites: valides.reduce((s, l) => s + Number(l.unites || 0), 0),
      euros: valides.reduce((s, l) => s + Number(l.montant_euros || 0), 0)
    };
  }, [lignes]);

  async function ajouterLigne(e) {
    e.preventDefault();
    setErreur("");
    const h = parseFloat(String(heures).replace(",", "."));
    if (!h || h <= 0) return setErreur("Indiquez un nombre d'heures valide.");
    if (travailleurId === chantier.beneficiaire_id)
      return setErreur(
        "Le bénéficiaire du chantier ne peut pas être travailleur sur ses propres lignes."
      );

    setEnvoi(true);
    const { error } = await supabase.from("echanges").insert({
      chantier_id: chantier.id,
      date_echange: chantier.date_chantier,
      travailleur_id: travailleurId,
      beneficiaire_id: chantier.beneficiaire_id,
      type_travail_id: typeId,
      heures: h,
      cree_par: user.id
    });
    setEnvoi(false);
    if (error) setErreur("Ajout impossible : " + error.message);
    else {
      setHeures("");
      if (peutToutSaisir) setTravailleurId("");
      charger();
    }
  }

  async function supprimerLigne(ligne) {
    const { error } = await supabase
      .from("echanges")
      .delete()
      .eq("id", ligne.id);
    if (error) setErreur("Suppression impossible : " + error.message);
    else charger();
  }

  if (!chantier) return <p className="text-ink/50">Chargement…</p>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-bold">
          {chantier.description || "Chantier"}
        </h1>
        <p className="text-ink/60">
          Chez {nomComplet(chantier.beneficiaire)} ·{" "}
          {fmtDate(chantier.date_chantier)}
        </p>
        <p className="text-sm font-semibold text-prairie-dark mt-1">
          Total validé : {fmtUnites(totaux.unites)} unités ·{" "}
          {fmtEuros(totaux.euros)}
        </p>
      </div>

      <section className="space-y-2">
        <h2 className="font-display font-bold text-lg">Participants</h2>
        {lignes.length === 0 && (
          <p className="text-ink/50 text-sm">
            Aucune ligne pour le moment. Ajoutez les participants ci-dessous.
          </p>
        )}
        {lignes.map((l) => (
          <div
            key={l.id}
            className="carte py-3 flex items-center justify-between gap-3"
          >
            <div className="min-w-0">
              <p className="font-semibold truncate">
                {nomComplet(l.travailleur)}
              </p>
              <p className="text-sm text-ink/60">
                {l.type?.libelle} · {fmtUnites(l.heures)} h ·{" "}
                {fmtUnites(l.unites)} u · {fmtEuros(l.montant_euros)}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Statut statut={l.statut} />
              {l.statut === "en_attente" &&
                (l.cree_par === user.id ||
                  profil?.role === "responsable") && (
                  <button
                    onClick={() => supprimerLigne(l)}
                    className="text-terre p-1.5 rounded-lg hover:bg-terre/10"
                    title="Supprimer la ligne"
                  >
                    <Trash2 size={18} />
                  </button>
                )}
            </div>
          </div>
        ))}
      </section>

      <section className="carte space-y-4">
        <h2 className="font-display font-bold text-lg">Ajouter une ligne</h2>

        {peutToutSaisir ? (
          <div>
            <label className="etiquette">Adhérent qui a travaillé</label>
            <select
              className="champ"
              value={travailleurId}
              onChange={(e) => setTravailleurId(e.target.value)}
              required
            >
              <option value="">— Choisir —</option>
              {adherents
                .filter((a) => a.id !== chantier.beneficiaire_id)
                .map((a) => (
                  <option key={a.id} value={a.id}>
                    {nomComplet(a)}
                  </option>
                ))}
            </select>
          </div>
        ) : (
          <p className="text-sm text-ink/60">
            Vous ajoutez votre propre participation à ce chantier.
          </p>
        )}

        <form onSubmit={ajouterLigne} className="space-y-4">
          <div>
            <label className="etiquette">Type de travail</label>
            <select
              className="champ"
              value={typeId}
              onChange={(e) => setTypeId(e.target.value)}
              required
            >
              <option value="">— Choisir —</option>
              {types.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.libelle} ({fmtUnites(t.taux_unites)} u/h)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="etiquette">Heures</label>
            <input
              type="text"
              inputMode="decimal"
              className="champ"
              placeholder="ex : 4"
              value={heures}
              onChange={(e) => setHeures(e.target.value)}
              required
            />
          </div>

          {erreur && <p className="text-terre text-sm">{erreur}</p>}

          <button className="btn-primaire w-full" disabled={envoi}>
            Ajouter au chantier
          </button>
        </form>
      </section>
    </div>
  );
}
