"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { nomComplet } from "@/lib/format";

export default function NouveauChantier() {
  const { user } = useAuth();
  const router = useRouter();
  const [adherents, setAdherents] = useState([]);
  const aujourdHui = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(aujourdHui);
  const [beneficiaireId, setBeneficiaireId] = useState("");
  const [description, setDescription] = useState("");
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    supabase
      .from("profils")
      .select("id, nom, prenom, email")
      .eq("role", "adherent")
      .eq("actif", true)
      .order("nom")
      .then(({ data }) => setAdherents(data || []));
  }, []);

  async function creer(e) {
    e.preventDefault();
    setErreur("");
    setEnvoi(true);
    const { data, error } = await supabase
      .from("chantiers")
      .insert({
        date_chantier: date,
        beneficiaire_id: beneficiaireId,
        description,
        cree_par: user.id
      })
      .select("id")
      .single();
    setEnvoi(false);
    if (error) setErreur("Création impossible : " + error.message);
    else router.push(`/chantiers/${data.id}`);
  }

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <h1 className="font-display text-2xl font-bold">Nouveau chantier</h1>
      <p className="text-sm text-ink/60">
        Créez le chantier, puis ajoutez une ligne par adhérent participant.
        Chacun validera ensuite ses lignes depuis son téléphone.
      </p>

      <form onSubmit={creer} className="carte space-y-4">
        <div>
          <label className="etiquette">Date du chantier</label>
          <input
            type="date"
            className="champ"
            value={date}
            max={aujourdHui}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="etiquette">Chez quel adhérent ?</label>
          <select
            className="champ"
            value={beneficiaireId}
            onChange={(e) => setBeneficiaireId(e.target.value)}
            required
          >
            <option value="">— Choisir —</option>
            {adherents.map((a) => (
              <option key={a.id} value={a.id}>
                {nomComplet(a)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="etiquette">Description</label>
          <input
            className="champ"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="ex : Ensilage maïs"
            required
          />
        </div>

        {erreur && <p className="text-terre text-sm">{erreur}</p>}

        <button className="btn-primaire w-full" disabled={envoi}>
          Créer le chantier
        </button>
      </form>
    </div>
  );
}
