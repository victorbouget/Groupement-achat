"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { fmtDate, nomComplet } from "@/lib/format";
import { Plus } from "lucide-react";

export default function PageChantiers() {
  const [chantiers, setChantiers] = useState([]);
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    supabase
      .from("chantiers")
      .select(
        `*,
         beneficiaire:profils!chantiers_beneficiaire_id_fkey(nom, prenom, email),
         echanges(id, statut)`
      )
      .order("date_chantier", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        setChantiers(data || []);
        setChargement(false);
      });
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold">Chantiers</h1>
        <Link href="/chantiers/nouveau" className="btn-primaire">
          <Plus size={18} /> Nouveau
        </Link>
      </div>

      {chargement && <p className="text-ink/50">Chargement…</p>}
      {!chargement && chantiers.length === 0 && (
        <p className="text-ink/50">
          Aucun chantier enregistré. Créez le premier — par exemple le prochain
          chantier d'ensilage.
        </p>
      )}

      <div className="space-y-2">
        {chantiers.map((c) => {
          const total = c.echanges?.length || 0;
          const valides = (c.echanges || []).filter(
            (e) => e.statut === "valide"
          ).length;
          return (
            <Link
              key={c.id}
              href={`/chantiers/${c.id}`}
              className="carte block hover:border-prairie/40"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold truncate">
                    {c.description || "Chantier"} — chez{" "}
                    {nomComplet(c.beneficiaire)}
                  </p>
                  <p className="text-sm text-ink/60">
                    {fmtDate(c.date_chantier)}
                  </p>
                </div>
                <span className="chip bg-prairie-light text-prairie-dark shrink-0">
                  {valides}/{total} validé{valides > 1 ? "s" : ""}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
