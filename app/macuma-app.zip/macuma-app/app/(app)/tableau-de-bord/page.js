"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { fmtUnites, fmtEuros, fmtDate, nomComplet } from "@/lib/format";
import { ArrowRight } from "lucide-react";
import { Statut } from "@/lib/Statut";

const SELECTION_ECHANGE = `
  *,
  travailleur:profils!echanges_travailleur_id_fkey(nom, prenom, email),
  beneficiaire:profils!echanges_beneficiaire_id_fkey(nom, prenom, email),
  type:types_travail(libelle)
`;

export default function TableauDeBord() {
  const { user, profil } = useAuth();
  const [solde, setSolde] = useState(null);
  const [recents, setRecents] = useState([]);
  const [aValider, setAValider] = useState(0);

  const charger = useCallback(async () => {
    if (!user) return;

    const [{ data: s }, { data: e }, { count }] = await Promise.all([
      supabase.from("soldes").select("*").eq("id", user.id).maybeSingle(),
      supabase
        .from("echanges")
        .select(SELECTION_ECHANGE)
        .or(`travailleur_id.eq.${user.id},beneficiaire_id.eq.${user.id}`)
        .order("cree_le", { ascending: false })
        .limit(8),
      supabase
        .from("echanges")
        .select("id", { count: "exact", head: true })
        .eq("statut", "en_attente")
        .or(`travailleur_id.eq.${user.id},beneficiaire_id.eq.${user.id}`)
        .neq("cree_par", user.id)
    ]);

    setSolde(s);
    setRecents(e || []);
    setAValider(count || 0);
  }, [user]);

  useEffect(() => {
    charger();
    // Solde en direct : on recharge dès qu'un échange bouge
    const canal = supabase
      .channel("maj-echanges")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "echanges" },
        charger
      )
      .subscribe();
    return () => supabase.removeChannel(canal);
  }, [charger]);

  const estAdherent = profil?.role === "adherent";
  const positif = (solde?.solde_unites ?? 0) >= 0;

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-bold">
        Bonjour {profil?.prenom || ""} 👋
      </h1>

      {estAdherent ? (
        <section
          className={`rounded-2xl p-5 text-white ${
            positif ? "bg-prairie" : "bg-terre"
          }`}
        >
          <p className="text-white/80 text-sm font-semibold uppercase tracking-wide">
            Mon solde
          </p>
          <p className="font-display text-5xl font-extrabold mt-1">
            {solde ? fmtUnites(solde.solde_unites) : "…"}
            <span className="text-2xl font-bold ml-2">unités</span>
          </p>
          <p className="text-white/90 mt-1 text-lg">
            soit {solde ? fmtEuros(solde.solde_euros) : "…"}
          </p>
          {solde &&
            solde.solde_unites_provisoire !== solde.solde_unites && (
              <p className="text-white/75 text-sm mt-2">
                Provisoire (avec les échanges en attente) :{" "}
                {fmtUnites(solde.solde_unites_provisoire)} unités —{" "}
                {fmtEuros(solde.solde_euros_provisoire)}
              </p>
            )}
        </section>
      ) : (
        <section className="carte">
          <p className="text-ink/70">
            Compte {profil?.role === "salarie" ? "salarié" : "responsable"} :
            pas de solde personnel. Vous pouvez saisir des chantiers et des
            échanges pour les adhérents.
          </p>
        </section>
      )}

      {aValider > 0 && (
        <Link
          href="/validation"
          className="carte flex items-center justify-between bg-paille/20 border-paille"
        >
          <span className="font-semibold">
            {aValider} échange{aValider > 1 ? "s" : ""} en attente de votre
            validation
          </span>
          <ArrowRight size={20} />
        </Link>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Link href="/saisie" className="btn-primaire">
          Saisir un échange
        </Link>
        <Link href="/chantiers/nouveau" className="btn-secondaire">
          Nouveau chantier
        </Link>
      </div>

      <section>
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-display font-bold text-lg">Derniers échanges</h2>
          <Link href="/soldes" className="text-sm text-prairie underline">
            Voir tous les soldes
          </Link>
        </div>
        <div className="space-y-2">
          {recents.length === 0 && (
            <p className="text-ink/50 text-sm">
              Aucun échange pour le moment. Saisissez le premier !
            </p>
          )}
          {recents.map((e) => (
            <LigneEchange key={e.id} e={e} moi={user.id} />
          ))}
        </div>
      </section>
    </div>
  );
}

function LigneEchange({ e, moi }) {
  const donne = e.travailleur_id === moi;
  return (
    <div className="carte py-3 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="font-semibold truncate">
          {donne
            ? `Pour ${nomComplet(e.beneficiaire)}`
            : `Par ${nomComplet(e.travailleur)}`}
        </p>
        <p className="text-sm text-ink/60 truncate">
          {e.type?.libelle} · {fmtUnites(e.heures)} h · {fmtDate(e.date_echange)}
        </p>
      </div>
      <div className="text-right shrink-0">
        <p className={`font-display font-bold ${donne ? "text-prairie" : "text-terre"}`}>
          {donne ? "+" : "−"}{fmtUnites(e.unites)} u
        </p>
        <Statut statut={e.statut} />
      </div>
    </div>
  );
}
