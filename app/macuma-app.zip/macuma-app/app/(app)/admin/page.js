"use client";

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { fmtUnites, fmtEuros, fmtDate, nomComplet } from "@/lib/format";

const ONGLETS = [
  { id: "membres", label: "Membres" },
  { id: "types", label: "Types de travail" },
  { id: "unite", label: "Valeur de l'unité" },
  { id: "campagnes", label: "Campagnes" }
];

export default function PageAdmin() {
  const { profil } = useAuth();
  const [onglet, setOnglet] = useState("membres");

  if (profil && profil.role !== "responsable") {
    return (
      <p className="text-ink/60">
        Cette page est réservée aux responsables de la banque de travail.
      </p>
    );
  }

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-bold">Administration</h1>

      <div className="flex gap-2 flex-wrap">
        {ONGLETS.map((o) => (
          <button
            key={o.id}
            onClick={() => setOnglet(o.id)}
            className={`px-3 py-2 rounded-xl text-sm font-semibold ${
              onglet === o.id
                ? "bg-prairie text-white"
                : "bg-white border border-ink/10 text-ink/70"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>

      {onglet === "membres" && <OngletMembres />}
      {onglet === "types" && <OngletTypes />}
      {onglet === "unite" && <OngletUnite />}
      {onglet === "campagnes" && <OngletCampagnes />}
    </div>
  );
}

/* ----------------------------- Membres ----------------------------- */

function OngletMembres() {
  const [membres, setMembres] = useState([]);
  const [erreur, setErreur] = useState("");

  const charger = useCallback(() => {
    supabase
      .from("profils")
      .select("*")
      .order("nom")
      .then(({ data }) => setMembres(data || []));
  }, []);

  useEffect(() => {
    charger();
  }, [charger]);

  async function maj(id, champs) {
    setErreur("");
    const { error } = await supabase.from("profils").update(champs).eq("id", id);
    if (error) setErreur("Modification impossible : " + error.message);
    else charger();
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-ink/60">
        Chaque membre crée son compte sur la page de connexion, puis vous lui
        attribuez ici son rôle. Décochez « actif » pour un départ.
      </p>
      {erreur && <p className="text-terre text-sm">{erreur}</p>}
      {membres.map((m) => (
        <div key={m.id} className="carte flex flex-wrap items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="font-semibold truncate">{nomComplet(m)}</p>
            <p className="text-sm text-ink/50 truncate">{m.email}</p>
          </div>
          <select
            className="champ !w-auto !py-2"
            value={m.role}
            onChange={(e) => maj(m.id, { role: e.target.value })}
          >
            <option value="adherent">Adhérent</option>
            <option value="salarie">Salarié</option>
            <option value="responsable">Responsable</option>
          </select>
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input
              type="checkbox"
              checked={m.actif}
              onChange={(e) => maj(m.id, { actif: e.target.checked })}
              className="w-5 h-5 accent-prairie"
            />
            Actif
          </label>
        </div>
      ))}
    </div>
  );
}

/* ------------------------- Types de travail ------------------------- */

function OngletTypes() {
  const [types, setTypes] = useState([]);
  const [libelle, setLibelle] = useState("");
  const [taux, setTaux] = useState("");
  const [erreur, setErreur] = useState("");

  const charger = useCallback(() => {
    supabase
      .from("types_travail")
      .select("*")
      .order("libelle")
      .then(({ data }) => setTypes(data || []));
  }, []);

  useEffect(() => {
    charger();
  }, [charger]);

  async function ajouter(e) {
    e.preventDefault();
    setErreur("");
    const t = parseFloat(String(taux).replace(",", "."));
    if (!t || t <= 0) return setErreur("Indiquez un taux d'unités valide.");
    const { error } = await supabase
      .from("types_travail")
      .insert({ libelle, taux_unites: t });
    if (error) setErreur("Ajout impossible : " + error.message);
    else {
      setLibelle("");
      setTaux("");
      charger();
    }
  }

  async function maj(id, champs) {
    setErreur("");
    const { error } = await supabase
      .from("types_travail")
      .update(champs)
      .eq("id", id);
    if (error) setErreur("Modification impossible : " + error.message);
    else charger();
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-ink/60">
        Modifier un taux ne change que les prochains échanges : les échanges
        déjà saisis gardent le taux photographié à leur création.
      </p>
      {erreur && <p className="text-terre text-sm">{erreur}</p>}

      {types.map((t) => (
        <LigneType key={t.id} t={t} onMaj={maj} />
      ))}

      <form onSubmit={ajouter} className="carte flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-40">
          <label className="etiquette">Nouveau type</label>
          <input
            className="champ"
            value={libelle}
            onChange={(e) => setLibelle(e.target.value)}
            placeholder="ex : Moisson + benne"
            required
          />
        </div>
        <div className="w-32">
          <label className="etiquette">Unités / h</label>
          <input
            className="champ"
            inputMode="decimal"
            value={taux}
            onChange={(e) => setTaux(e.target.value)}
            placeholder="7,5"
            required
          />
        </div>
        <button className="btn-primaire">Ajouter</button>
      </form>
    </div>
  );
}

function LigneType({ t, onMaj }) {
  const [taux, setTaux] = useState(String(t.taux_unites));
  const modifie = parseFloat(taux.replace(",", ".")) !== Number(t.taux_unites);

  return (
    <div className="carte flex flex-wrap items-center gap-3">
      <p className="font-semibold flex-1 min-w-40">{t.libelle}</p>
      <div className="flex items-center gap-2">
        <input
          className="champ !w-24 !py-2 text-right"
          inputMode="decimal"
          value={taux}
          onChange={(e) => setTaux(e.target.value)}
        />
        <span className="text-sm text-ink/50">u/h</span>
        {modifie && (
          <button
            className="btn-secondaire !py-2"
            onClick={() =>
              onMaj(t.id, { taux_unites: parseFloat(taux.replace(",", ".")) })
            }
          >
            Enregistrer
          </button>
        )}
      </div>
      <label className="flex items-center gap-2 text-sm font-semibold">
        <input
          type="checkbox"
          checked={t.actif}
          onChange={(e) => onMaj(t.id, { actif: e.target.checked })}
          className="w-5 h-5 accent-prairie"
        />
        Actif
      </label>
    </div>
  );
}

/* ------------------------- Valeur de l'unité ------------------------ */

function OngletUnite() {
  const [valeurs, setValeurs] = useState([]);
  const [valeur, setValeur] = useState("");
  const [dateEffet, setDateEffet] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [erreur, setErreur] = useState("");
  const { user } = useAuth();

  const charger = useCallback(() => {
    supabase
      .from("valeurs_unite")
      .select("*")
      .order("date_effet", { ascending: false })
      .then(({ data }) => setValeurs(data || []));
  }, []);

  useEffect(() => {
    charger();
  }, [charger]);

  async function ajouter(e) {
    e.preventDefault();
    setErreur("");
    const v = parseFloat(String(valeur).replace(",", "."));
    if (!v || v <= 0) return setErreur("Indiquez une valeur en euros valide.");
    const { error } = await supabase
      .from("valeurs_unite")
      .insert({ valeur_euros: v, date_effet: dateEffet, cree_par: user.id });
    if (error) setErreur("Ajout impossible : " + error.message);
    else {
      setValeur("");
      charger();
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-ink/60">
        La nouvelle valeur s'applique aux échanges datés à partir de sa date
        d'effet. Les échanges déjà saisis gardent leur valeur d'origine.
      </p>
      {erreur && <p className="text-terre text-sm">{erreur}</p>}

      <form onSubmit={ajouter} className="carte flex flex-wrap items-end gap-3">
        <div className="w-36">
          <label className="etiquette">Valeur (€/unité)</label>
          <input
            className="champ"
            inputMode="decimal"
            value={valeur}
            onChange={(e) => setValeur(e.target.value)}
            placeholder="6,00"
            required
          />
        </div>
        <div className="w-44">
          <label className="etiquette">À partir du</label>
          <input
            type="date"
            className="champ"
            value={dateEffet}
            onChange={(e) => setDateEffet(e.target.value)}
            required
          />
        </div>
        <button className="btn-primaire">Enregistrer</button>
      </form>

      <div className="carte p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-prairie-light text-prairie-dark text-left">
              <th className="px-3 py-2 font-semibold">À partir du</th>
              <th className="px-3 py-2 font-semibold text-right">Valeur</th>
            </tr>
          </thead>
          <tbody>
            {valeurs.map((v, i) => (
              <tr key={v.id} className="border-t border-ink/5">
                <td className="px-3 py-2.5">
                  {fmtDate(v.date_effet)}
                  {i === 0 && (
                    <span className="chip bg-prairie-light text-prairie-dark ml-2">
                      En vigueur
                    </span>
                  )}
                </td>
                <td className="px-3 py-2.5 text-right font-semibold">
                  {fmtEuros(v.valeur_euros)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ----------------------------- Campagnes ---------------------------- */

function OngletCampagnes() {
  const [campagnes, setCampagnes] = useState([]);
  const [soldesCampagne, setSoldesCampagne] = useState([]);
  const [campagneOuverte, setCampagneOuverte] = useState(null);
  const [libelle, setLibelle] = useState("");
  const [debut, setDebut] = useState("");
  const [fin, setFin] = useState("");
  const [erreur, setErreur] = useState("");

  const charger = useCallback(() => {
    supabase
      .from("campagnes")
      .select("*")
      .order("date_debut", { ascending: false })
      .then(({ data }) => setCampagnes(data || []));
  }, []);

  useEffect(() => {
    charger();
  }, [charger]);

  async function ajouter(e) {
    e.preventDefault();
    setErreur("");
    const { error } = await supabase
      .from("campagnes")
      .insert({ libelle, date_debut: debut, date_fin: fin });
    if (error) setErreur("Ajout impossible : " + error.message);
    else {
      setLibelle("");
      setDebut("");
      setFin("");
      charger();
    }
  }

  async function voirBilan(c) {
    setCampagneOuverte(c);
    const { data } = await supabase
      .from("soldes_par_campagne")
      .select("*")
      .eq("campagne_id", c.id)
      .order("nom");
    setSoldesCampagne(data || []);
  }

  async function basculerCloture(c) {
    const { error } = await supabase
      .from("campagnes")
      .update({ cloturee: !c.cloturee })
      .eq("id", c.id);
    if (error) setErreur("Modification impossible : " + error.message);
    else charger();
  }

  return (
    <div className="space-y-3">
      {erreur && <p className="text-terre text-sm">{erreur}</p>}

      {campagnes.map((c) => (
        <div key={c.id} className="carte space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex-1 min-w-40">
              <p className="font-semibold">{c.libelle}</p>
              <p className="text-sm text-ink/50">
                {fmtDate(c.date_debut)} → {fmtDate(c.date_fin)}
                {c.cloturee && " · clôturée"}
              </p>
            </div>
            <button className="btn-secondaire !py-2" onClick={() => voirBilan(c)}>
              Bilan
            </button>
            <button className="btn-danger !py-2" onClick={() => basculerCloture(c)}>
              {c.cloturee ? "Rouvrir" : "Clôturer"}
            </button>
          </div>

          {campagneOuverte?.id === c.id && (
            <table className="w-full text-sm mt-2">
              <thead>
                <tr className="text-left text-ink/50">
                  <th className="py-1 font-semibold">Adhérent</th>
                  <th className="py-1 font-semibold text-right">Unités</th>
                  <th className="py-1 font-semibold text-right">Euros</th>
                </tr>
              </thead>
              <tbody>
                {soldesCampagne.map((s) => (
                  <tr key={s.id} className="border-t border-ink/5">
                    <td className="py-1.5">
                      {s.prenom} {s.nom}
                    </td>
                    <td
                      className={`py-1.5 text-right font-semibold ${
                        s.solde_unites >= 0 ? "text-prairie" : "text-terre"
                      }`}
                    >
                      {fmtUnites(s.solde_unites)}
                    </td>
                    <td className="py-1.5 text-right">
                      {fmtEuros(s.solde_euros)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ))}

      <form onSubmit={ajouter} className="carte flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-40">
          <label className="etiquette">Nouvelle campagne</label>
          <input
            className="champ"
            value={libelle}
            onChange={(e) => setLibelle(e.target.value)}
            placeholder="ex : Campagne 2027"
            required
          />
        </div>
        <div>
          <label className="etiquette">Début</label>
          <input type="date" className="champ" value={debut} onChange={(e) => setDebut(e.target.value)} required />
        </div>
        <div>
          <label className="etiquette">Fin</label>
          <input type="date" className="champ" value={fin} onChange={(e) => setFin(e.target.value)} required />
        </div>
        <button className="btn-primaire">Ajouter</button>
      </form>
    </div>
  );
}
