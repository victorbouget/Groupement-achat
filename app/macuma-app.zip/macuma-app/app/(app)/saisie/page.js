"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import { fmtUnites, fmtEuros, nomComplet } from "@/lib/format";

export default function PageSaisie() {
  const { user, profil } = useAuth();
  const router = useRouter();

  const [adherents, setAdherents] = useState([]);
  const [types, setTypes] = useState([]);
  const [valeurUnite, setValeurUnite] = useState(null);

  const aujourdHui = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(aujourdHui);
  const [travailleurId, setTravailleurId] = useState("");
  const [beneficiaireId, setBeneficiaireId] = useState("");
  const [typeId, setTypeId] = useState("");
  const [heures, setHeures] = useState("");
  const [commentaire, setCommentaire] = useState("");
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);

  const peutChoisirTravailleur =
    profil?.role === "salarie" || profil?.role === "responsable";

  useEffect(() => {
    async function charger() {
      const [{ data: a }, { data: t }, { data: v }] = await Promise.all([
        supabase
          .from("profils")
          .select("id, nom, prenom, email")
          .eq("role", "adherent")
          .eq("actif", true)
          .order("nom"),
        supabase
          .from("types_travail")
          .select("*")
          .eq("actif", true)
          .order("libelle"),
        supabase
          .from("valeurs_unite")
          .select("valeur_euros")
          .lte("date_effet", new Date().toISOString().slice(0, 10))
          .order("date_effet", { ascending: false })
          .limit(1)
      ]);
      setAdherents(a || []);
      setTypes(t || []);
      setValeurUnite(v?.[0]?.valeur_euros ?? null);
    }
    charger();
  }, []);

  useEffect(() => {
    if (user && !peutChoisirTravailleur) setTravailleurId(user.id);
  }, [user, peutChoisirTravailleur]);

  const type = types.find((t) => String(t.id) === String(typeId));
  const apercu = useMemo(() => {
    const h = parseFloat(String(heures).replace(",", "."));
    if (!type || !h || h <= 0) return null;
    const unites = h * Number(type.taux_unites);
    return {
      unites,
      euros: valeurUnite != null ? unites * Number(valeurUnite) : null
    };
  }, [type, heures, valeurUnite]);

  async function enregistrer(e) {
    e.preventDefault();
    setErreur("");
    const h = parseFloat(String(heures).replace(",", "."));
    if (!h || h <= 0) return setErreur("Indiquez un nombre d'heures valide.");
    if (travailleurId === beneficiaireId)
      return setErreur("Le travailleur et le bénéficiaire doivent être différents.");

    setEnvoi(true);
    const { error } = await supabase.from("echanges").insert({
      date_echange: date,
      travailleur_id: travailleurId,
      beneficiaire_id: beneficiaireId,
      type_travail_id: typeId,
      heures: h,
      commentaire: commentaire || null,
      cree_par: user.id
    });
    setEnvoi(false);
    if (error) setErreur("Enregistrement impossible : " + error.message);
    else router.push("/tableau-de-bord");
  }

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <h1 className="font-display text-2xl font-bold">Saisir un échange</h1>

      <form onSubmit={enregistrer} className="carte space-y-4">
        <div>
          <label className="etiquette">Date du travail</label>
          <input
            type="date"
            className="champ"
            value={date}
            max={aujourdHui}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        {peutChoisirTravailleur && (
          <div>
            <label className="etiquette">Qui a travaillé ?</label>
            <select
              className="champ"
              value={travailleurId}
              onChange={(e) => setTravailleurId(e.target.value)}
              required
            >
              <option value="">— Choisir un adhérent —</option>
              {adherents.map((a) => (
                <option key={a.id} value={a.id}>
                  {nomComplet(a)}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label className="etiquette">
            {peutChoisirTravailleur ? "Chez qui ?" : "J'ai travaillé chez…"}
          </label>
          <select
            className="champ"
            value={beneficiaireId}
            onChange={(e) => setBeneficiaireId(e.target.value)}
            required
          >
            <option value="">— Choisir un adhérent —</option>
            {adherents
              .filter((a) => a.id !== travailleurId)
              .map((a) => (
                <option key={a.id} value={a.id}>
                  {nomComplet(a)}
                </option>
              ))}
          </select>
        </div>

        <div>
          <label className="etiquette">Type de travail</label>
          <select
            className="champ"
            value={typeId}
            onChange={(e) => setTypeId(e.target.value)}
            required
          >
            <option value="">— Choisir —</option>
            {types.map((t) => (
              <option key={t.id} value={t.id}>
                {t.libelle} ({fmtUnites(t.taux_unites)} u/h)
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="etiquette">Nombre d'heures</label>
          <input
            type="text"
            inputMode="decimal"
            className="champ"
            placeholder="ex : 2,5"
            value={heures}
            onChange={(e) => setHeures(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="etiquette">Commentaire (facultatif)</label>
          <input
            className="champ"
            value={commentaire}
            onChange={(e) => setCommentaire(e.target.value)}
            placeholder="ex : transport maïs parcelle du bas"
          />
        </div>

        {apercu && (
          <div className="rounded-xl bg-prairie-light p-3 text-prairie-dark font-semibold">
            = {fmtUnites(apercu.unites)} unités
            {apercu.euros != null && <> · {fmtEuros(apercu.euros)}</>}
          </div>
        )}

        {erreur && <p className="text-terre text-sm">{erreur}</p>}

        <button className="btn-primaire w-full" disabled={envoi}>
          Enregistrer l'échange
        </button>
        <p className="text-xs text-ink/50">
          L'échange restera « en attente » jusqu'à sa validation par l'autre
          partie.
        </p>
      </form>
    </div>
  );
}
