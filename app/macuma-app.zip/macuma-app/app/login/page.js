"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";

export default function PageConnexion() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const [mode, setMode] = useState("connexion"); // connexion | inscription
  const [email, setEmail] = useState("");
  const [motDePasse, setMotDePasse] = useState("");
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [erreur, setErreur] = useState("");
  const [info, setInfo] = useState("");
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    if (!loading && user) router.replace("/tableau-de-bord");
  }, [user, loading, router]);

  async function envoyer(e) {
    e.preventDefault();
    setErreur("");
    setInfo("");
    setEnvoi(true);
    if (mode === "connexion") {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password: motDePasse
      });
      if (error) setErreur("Connexion impossible : " + error.message);
      else router.replace("/tableau-de-bord");
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password: motDePasse,
        options: { data: { nom, prenom } }
      });
      if (error) setErreur("Inscription impossible : " + error.message);
      else
        setInfo(
          "Compte créé. Si la confirmation par e-mail est activée, vérifiez votre boîte mail, puis connectez-vous."
        );
    }
    setEnvoi(false);
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <div className="font-display text-4xl font-extrabold text-prairie-dark tracking-tight">
            Macuma
          </div>
          <p className="text-ink/60 mt-1">Banque de travail de la CUMA</p>
        </div>

        <form onSubmit={envoyer} className="carte space-y-4">
          {mode === "inscription" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="etiquette">Prénom</label>
                <input className="champ" value={prenom} onChange={(e) => setPrenom(e.target.value)} required />
              </div>
              <div>
                <label className="etiquette">Nom</label>
                <input className="champ" value={nom} onChange={(e) => setNom(e.target.value)} required />
              </div>
            </div>
          )}
          <div>
            <label className="etiquette">E-mail</label>
            <input type="email" className="champ" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="etiquette">Mot de passe</label>
            <input
              type="password"
              className="champ"
              value={motDePasse}
              onChange={(e) => setMotDePasse(e.target.value)}
              required
              minLength={6}
            />
          </div>

          {erreur && <p className="text-terre text-sm">{erreur}</p>}
          {info && <p className="text-prairie text-sm">{info}</p>}

          <button className="btn-primaire w-full" disabled={envoi}>
            {mode === "connexion" ? "Se connecter" : "Créer mon compte"}
          </button>

          <button
            type="button"
            className="w-full text-sm text-prairie underline"
            onClick={() => {
              setMode(mode === "connexion" ? "inscription" : "connexion");
              setErreur("");
              setInfo("");
            }}
          >
            {mode === "connexion"
              ? "Première visite ? Créer un compte"
              : "Déjà un compte ? Se connecter"}
          </button>
        </form>
      </div>
    </main>
  );
}
