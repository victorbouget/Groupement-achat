/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./lib/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        fond: "#F4F5F1",
        ink: "#1F2A24",
        prairie: {
          DEFAULT: "#2D6A4F",
          dark: "#1B4332",
          light: "#E6F0EB"
        },
        paille: "#E9C46A",
        terre: "#B5543B"
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"]
      }
    }
  },
  plugins: []
};
